"""Kronos threshold variant (kronos_threshold_v1) for freqtrade 2026.8.

Rendered by kronos.research.verdict.kernel.strategy_template (P08).
Parameters: atr_period=2, volatility_multiplier=1.0.
Do not edit by hand: regenerate via the template instead.
"""

from __future__ import annotations

from datetime import datetime

import numpy as np
import pandas as pd
from freqtrade.strategy import IStrategy

TF_MS = 900_000
DAY_MS = 86_400_000
BARS_PER_UTC_DAY = 96
ENTRY_LONG_THRESHOLD = 1.0
ENTRY_SHORT_THRESHOLD = -1.0


class KronosThresholdVariant(IStrategy):
    """Threshold variant on 15m futures: full-equity single position, 1x."""

    timeframe = "15m"
    can_short = True
    minimal_roi: dict = {}
    stoploss = -1.0
    trailing_stop = False
    process_only_new_candles = True
    use_exit_signal = True
    exit_profit_only = False
    position_adjustment_enable = False

    # Warmup gate: first actionable signal bar == required_warmup_bars - 1
    # (96 + atr_period - 1), matching reference_ledger's
    # `index + 1 >= required_warmup_bars` (M0 evidence, case G05).
    atr_period = 2
    volatility_multiplier = 1.0
    startup_candle_count = 97

    def leverage(
        self, pair, current_time, current_rate, proposed_leverage, max_leverage, entry_tag, side,
        **kwargs,
    ) -> float:
        return 1.0

    # --- no-same-candle reversal guard (frozen rule 2) ----------------------
    # Native freqtrade (CAN_SHORT) closes and re-enters the opposite side
    # within the same candle row when the shifted signals contain both the
    # exit and the opposite entry.  The frozen rules forbid this: the earliest
    # re-entry is off the NEXT bar's close.  Guard: reject any entry whose
    # current_time equals the last exit's current_time (both callbacks are
    # invoked by the backtester with the candle-open time).

    _last_exit_candle: datetime | None = None

    def confirm_trade_exit(
        self, pair, trade, order_type, amount, rate, time_in_force, exit_reason,
        current_time, **kwargs,
    ) -> bool:
        self._last_exit_candle = current_time
        return True

    def confirm_trade_entry(
        self, pair, order_type, amount, rate, time_in_force, current_time,
        entry_tag, side, **kwargs,
    ) -> bool:
        if self._last_exit_candle is not None and current_time == self._last_exit_candle:
            return False
        return True

    def informative_pairs(self):
        return []

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        df = dataframe
        # --- previous COMPLETE UTC day H/L/C (exactly 96 bars required) -----
        day_key = df["date"].dt.floor("1D")
        agg = (
            df.assign(_day=day_key)
            .groupby("_day", sort=True)
            .agg(dh=("high", "max"), dl=("low", "min"), dc=("close", "last"), dn=("close", "size"))
        )
        agg["ph"] = agg["dh"].shift(1)
        agg["pl"] = agg["dl"].shift(1)
        agg["pc"] = agg["dc"].shift(1)
        agg["pn"] = agg["dn"].shift(1)
        df = df.merge(agg[["ph", "pl", "pc", "pn"]], left_on=day_key, right_index=True, how="left")
        prev_complete = df["pn"] == BARS_PER_UTC_DAY

        # --- true range + ATR: sequential, bit-identical to the reference ---
        high = df["high"].to_numpy(dtype=float)
        low = df["low"].to_numpy(dtype=float)
        close = df["close"].to_numpy(dtype=float)
        n = len(df)
        tr = np.empty(n, dtype=float)
        prev_close = None
        for i in range(n):
            tr[i] = (
                high[i] - low[i]
                if prev_close is None
                else max(high[i] - low[i], abs(high[i] - prev_close), abs(low[i] - prev_close))
            )
            prev_close = close[i]

        k = int(self.atr_period)
        window: list[float] = []
        tr_sum = 0.0
        atr = np.full(n, np.nan)
        for i in range(n):
            window.append(tr[i])
            tr_sum += tr[i]
            if len(window) > k:
                tr_sum -= window.pop(0)
            if len(window) == k and tr_sum > 0.0:
                atr[i] = tr_sum / k

        pivot = (df["ph"] + df["pl"] + df["pc"]) / 3.0
        q = np.full(n, np.nan)
        for i in range(n):
            if prev_complete.iat[i] and not np.isnan(atr[i]):
                q[i] = (close[i] - pivot.iat[i]) / (atr[i] * float(self.volatility_multiplier))
        df["q"] = q

        # day-end bar: close crosses the UTC day boundary (bar opening 23:45).
        # pandas 3.x stores datetimes at non-ns resolution -> normalize to ms.
        ts_ms = df["date"].astype("datetime64[ms, UTC]").astype("int64")
        df["day_end"] = (ts_ms + TF_MS) // DAY_MS != ts_ms // DAY_MS
        return df

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        q = dataframe["q"]
        ok = q.notna() & ~dataframe["day_end"]
        dataframe["enter_long"] = 0
        dataframe["enter_short"] = 0
        dataframe.loc[ok & (q >= ENTRY_LONG_THRESHOLD), ["enter_long", "enter_tag"]] = (1, "q_long")
        dataframe.loc[ok & (q <= ENTRY_SHORT_THRESHOLD), ["enter_short", "enter_tag"]] = (
            1,
            "q_short",
        )
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        q = dataframe["q"]
        dataframe["exit_long"] = 0
        dataframe["exit_short"] = 0
        # Day-end exits carry a distinct tag so the adapter can map them to
        # exit_reason='day_end_flat'; score exits map to 'signal_exit'.
        day_end = dataframe["day_end"].fillna(False)
        dataframe.loc[day_end | (q <= 0.0), ["exit_long", "exit_tag"]] = (1, "q_exit")
        dataframe.loc[day_end, ["exit_long", "exit_tag"]] = (1, "day_end")
        dataframe.loc[day_end | (q >= 0.0), ["exit_short", "exit_tag"]] = (1, "q_exit")
        dataframe.loc[day_end, ["exit_short", "exit_tag"]] = (1, "day_end")
        return dataframe
